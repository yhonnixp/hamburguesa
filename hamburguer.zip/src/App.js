import React, { useState } from 'react';
import Header from './pages/Header';
import Ingredientes from './pages/Ingredientes';
import Inicio from './pages/Inicio';

function App() {
  const [ingredientesSeleccionados, setIngredientesSeleccionados] = useState([]);

  return (
    <div>
      <Header />
      <Ingredientes
        ingredientesSeleccionados={ingredientesSeleccionados}
        setIngredientesSeleccionados={setIngredientesSeleccionados}
      />
      <Inicio mostrarImagen={ingredientesSeleccionados.length === 6} />
    </div>
  );
}

export default App;
