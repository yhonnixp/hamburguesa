import React from 'react';

const Inicio = ({ mostrarImagen }) => {
  return (
    <div className="container mt-4">
      <h1 className="text-center"> </h1>
      <div className="row justify-content-center">
        <div className="col-6">
          {mostrarImagen ? (
            <img
              src="https://i.ytimg.com/vi/7iutMHBHki4/maxresdefault.jpg"
              alt="Hamburguesa"
              className="img-fluid"
            />
          ) : (
            <p className="text-center text-danger"> </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Inicio;
