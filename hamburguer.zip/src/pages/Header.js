import React from 'react';

const Header = () => {
  return (
    <div className="container-fluid">
      <div className="row bg-dark text-white">
        <div className="col">
          <h2> Restaurante Cangreburguer</h2>
        </div>
      </div>
      <div className="row mt-3">
        <div className="col">
         
        </div>
      </div>
    </div>
  );
};

export default Header;
