import React, { useState } from 'react';

const Ingredientes = ({ setIngredientesSeleccionados }) => {
  const [ingredientesSeleccionados, actualizarIngredientesSeleccionados] = useState([]);
  const pasoAPaso = ["Pan inferior", "lechuga", "tomate", "mortadella", "salsa secreta", "Pan superior"];
  const [mostrarImagen, setMostrarImagen] = useState(false);

  const agregarIngrediente = (ingrediente) => {
    const nuevosIngredientes = [...ingredientesSeleccionados, ingrediente];
    actualizarIngredientesSeleccionados(nuevosIngredientes);
  };

  const cocinarHamburguesa = () => {
    setIngredientesSeleccionados(ingredientesSeleccionados);

    const esPasoCorrecto = JSON.stringify(ingredientesSeleccionados) === JSON.stringify(pasoAPaso);

    if (esPasoCorrecto) {
      alert("Hamburguesa creada con éxito");
      setMostrarImagen(true);
    } else {
      alert("PREPARA BONITO...");
      setMostrarImagen(false);
    }
  };

  return (
    <div className="container mt-4">
      <h1>Ingredientes</h1>
      <div className="btn-group">
        <button className="btn btn-primary" onClick={() => agregarIngrediente("Pan inferior")}>Pan inferior</button>
        <button className="btn btn-primary" onClick={() => agregarIngrediente("lechuga")}>Lechuga</button>
        <button className="btn btn-primary" onClick={() => agregarIngrediente("tomate")}>Tomate</button>
        <button className="btn btn-primary" onClick={() => agregarIngrediente("mortadella")}>Mortadella</button>
        <button className="btn btn-primary" onClick={() => agregarIngrediente("salsa secreta")}>Salsa secreta</button>
        <button className="btn btn-primary" onClick={() => agregarIngrediente("Pan superior")}>Pan superior</button>
      </div>

      <button className="btn btn-success mt-3" onClick={cocinarHamburguesa}>Cocinar</button>

      {mostrarImagen && (
        <img
          src="https://i.ytimg.com/vi/7iutMHBHki4/maxresdefault.jpg"
          alt="Hamburguesa"
          className="img-fluid mt-3"
        />
      )}

      {!mostrarImagen && (
        <p className="text-center text-danger mt-3">PREPARA BONITO...</p>
      )}
    </div>
  );
};

export default Ingredientes;
